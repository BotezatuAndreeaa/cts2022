package ex3.clase;

public interface Observer {
 public void primesteInformareManevre(String mesaj);
}
