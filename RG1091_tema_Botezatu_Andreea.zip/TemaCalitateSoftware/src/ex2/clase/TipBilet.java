package ex2.clase;

public interface TipBilet {
	public void anuleazaRezervare();
	public  float getPret();
}
