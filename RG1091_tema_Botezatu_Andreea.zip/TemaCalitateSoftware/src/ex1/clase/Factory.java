package ex1.clase;

public interface Factory {

	Bilet creareBilet(String aeroportPlecare, String aeroportDestinatie, float pret);
}
